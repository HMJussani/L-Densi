/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infraestrutura;

import jssc.SerialPort;
import testeserial.serial;

/**
 *
 * @author Rick
 *
 * Classe criada para gerenciar Threads que tem processos demorados
 */
public class ThreadLenta implements Runnable {

    serial serial = new serial();
    PortasSeriais portaCom = new PortasSeriais();
    private volatile boolean stop = false;
    private static SerialPort serialCom = null;
    private static String porta = null;

    public void setPorta(String porta) {
        this.porta = porta;
    }

    public void run() {
        String aux = null, aux2 = null;
        while (!stop) {
            serialCom = portaCom.abrePorta(porta);
            portaCom.enviaDados(serialCom, "v\r");
            if (serialCom.isOpened()) {
                aux = portaCom.recebeDados(serialCom, 40);
                aux2 = aux.substring(0, 5);
                if (aux2.equals("DMA35")) {
                    serial.setAchou(true);
                    serial.setporta(serialCom);
                }
                parar();
            }
        }
    }

    public void parar() {
        this.stop = true;
    }

}
