/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infraestrutura;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import jssc.SerialPort;
import jssc.SerialPortException;
import testeserial.serial;

/**
 *
 * @author Rick
 */
public class PortasSeriais {

    private SerialPort porta;
      
    public void setPorta(SerialPort porta) {
        this.porta = porta;
    }

    public SerialPort abrePorta(String porta) {
        SerialPort portaSerial = new SerialPort(porta);
        try {

            portaSerial.openPort();
            portaSerial.setParams(SerialPort.BAUDRATE_9600,
                    SerialPort.DATABITS_7,
                    SerialPort.STOPBITS_1,
                    SerialPort.PARITY_EVEN);

        } catch (SerialPortException ex) {
            System.out.println(ex);
        }
        return portaSerial;
    }

    public void enviaDados(SerialPort porta, String dado) {
        if (porta.isOpened()) {
            try {
                porta.writeString(dado);
            } catch (SerialPortException ex) {
                Logger.getLogger(serial.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (!porta.isOpened()) {
           // JOptionPane.showMessageDialog(null, "A porta não está aberta!");
        }
    }

    public String recebeDados(SerialPort porta,int num) {
        String lido = null;
        try {
            lido = porta.readString(num);
        } catch (SerialPortException ex) {
            Logger.getLogger(serial.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lido;
    }
}
