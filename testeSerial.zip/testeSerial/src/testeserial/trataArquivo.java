/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testeserial;

/**
 *
 * @author Rick Classe criada para "tratar" o arquivo recebido pela serial
 * separando o numero do elemento, temperatura e densidade que serão usados em
 * outros pontos do software
 */
public class trataArquivo {

    private String[] elemento = new String[60];
    private String[] temp = new String[60];
    private String[] densi = new String[60];

    public String trataArquivo(String arquivo) {
        int numLinha = 0;
        String tratado = "Elemento;Tempertura;Densidade\n";
        String[] linha = null;
        String[] recorte = null;
        for (int i = 0; i < arquivo.length(); i++) { //conta as linhas
            if (arquivo.charAt(i) == '\n') {
                numLinha++;
            }
        }
        linha = arquivo.split("\n"); // separa o arquivo em linhas
        for (int i = 2; i < numLinha; i++) {
            recorte = linha[i].split(" ");
            if (i <= 10) {
                elemento[i - 2] = recorte[3];
                temp[i - 2] = recorte[6];
                densi[i - 2] = recorte[8].substring(0, 5);
            } else if (i >= 11) {
                elemento[i - 2] = recorte[2];
                temp[i - 2] = recorte[5];
                densi[i - 2] = recorte[7].substring(0, 5);
            }
            tratado += elemento[i - 2] + ";";
            tratado += temp[i - 2] + ";";
            tratado += densi[i - 2] + ";";
            tratado += "\n";
        }

        return tratado;

    }

}
