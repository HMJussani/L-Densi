/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testeserial;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Rick
 */
public class GeraCsv {

    private static String caminho = "";
    private static String arquivo = "";
    private boolean existe = false;

    public static void setCaminho(String caminho) {
        GeraCsv.caminho = caminho;
    }

    public static void setArquivo(String arquivo) {
        GeraCsv.arquivo = arquivo;
    }

    public String getArquivo() {
        return arquivo;
    }

    public String getCaminho() {
        return caminho;
    }

    public boolean getExiste() {
        if (((!arquivo.equals("")) && (!arquivo.equals(".csv"))) && (!caminho.equals(""))) {
            existe = true;
        }

        return existe;
    }

    public void criaDir(String arquivo, String caminho) {
        String atalho = caminho + arquivo;
        File diretorio = new File(caminho); //instancia o diretorio a ser criado

        if (!diretorio.exists()) { //se nao exisir
            diretorio.mkdir();
            try {
                FileWriter writer = new FileWriter(atalho);
                writer.append("");
                writer.flush();
                writer.close();
            } catch (IOException ex) {
                Logger.getLogger(GeraCsv.class.getName()).log(Level.SEVERE, null, ex);
            }
//cria
        }

    }

    // gera o csv
    public void geraArquivoCsv(String arquivo, String caminho, String dados) {
        String atalho = caminho + arquivo;
        try {
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            Date data = new Date();
            FileWriter writer = new FileWriter(atalho, true);
            BufferedWriter buf = new BufferedWriter(writer);
            buf.write("Gerado em: "+formato.format(data));
            buf.newLine();
            buf.write(dados);
            buf.newLine();
            buf.flush();
            buf.close();
        } catch (IOException ex) {
            Logger.getLogger(GeraCsv.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
